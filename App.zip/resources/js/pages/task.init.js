/*
Template Name: Ubold - Responsive Bootstrap 4 Admin Dashboard
Author: CoderThemes
Website: https://coderthemes.com/
Contact: support@coderthemes.com
File: Task init js
*/

// Bubble theme
var quill = new Quill('#bubble-editor', {
    theme: 'bubble'
});