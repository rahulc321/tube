@extends('layouts.website')

@section('content')

 <div class="pading" style="padding-top: 150px !important"> 
 {!!  $pages->data !!}
 </div>
@endsection
